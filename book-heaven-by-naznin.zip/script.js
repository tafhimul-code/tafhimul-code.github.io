const KEY="book_heaven_books";
const fallback=[
 {id:"1",name:"রিয়াদুস সালেহীন",author:"ইমাম নববী (রহ.)",price:350,image:"",description:"হাদিসের গুরুত্বপূর্ণ সংকলন।"},
 {id:"2",name:"হিসনুল মুসলিম",author:"সাঈদ ইবন আলী আল-কাহতানী",price:220,image:"",description:"দৈনন্দিন জীবনের দোয়া ও যিকির।"},
 {id:"3",name:"নামাজের শিক্ষা",author:"Book Heaven",price:180,image:"",description:"নামাজ সম্পর্কে সহজ ও প্রয়োজনীয় শিক্ষা।"}
];
function getBooks(){try{return JSON.parse(localStorage.getItem(KEY))||fallback}catch(e){return fallback}}
function saveBooks(b){localStorage.setItem(KEY,JSON.stringify(b))}
function money(n){return "৳"+Number(n).toLocaleString("bn-BD")}
function renderBooks(){
 const grid=document.querySelector("#bookGrid"); if(!grid)return;
 const q=(document.querySelector("#search")?.value||"").toLowerCase();
 const books=getBooks().filter(b=>(b.name+" "+(b.author||"")).toLowerCase().includes(q));
 grid.innerHTML=books.length?books.map(b=>`<article class="book"><img src="${b.image||"assets/logo.jpg"}" alt="${b.name}"><div class="book-body"><h3>${b.name}</h3><div class="author">${b.author||"লেখক উল্লেখ নেই"}</div><div class="price">${money(b.price)}</div></div></article>`).join(""):"<p>কোনো বই পাওয়া যায়নি।</p>";
}
document.querySelector("#search")?.addEventListener("input",renderBooks);
renderBooks();
