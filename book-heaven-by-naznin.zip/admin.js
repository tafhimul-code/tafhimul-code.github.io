const KEY="book_heaven_books";
const fallback=[
{id:"1",name:"রিয়াদুস সালেহীন",author:"ইমাম নববী (রহ.)",price:350,image:"",description:"হাদিসের গুরুত্বপূর্ণ সংকলন।"},
{id:"2",name:"হিসনুল মুসলিম",author:"সাঈদ ইবন আলী আল-কাহতানী",price:220,image:"",description:"দৈনন্দিন জীবনের দোয়া ও যিকির।"},
{id:"3",name:"নামাজের শিক্ষা",author:"Book Heaven",price:180,image:"",description:"নামাজ সম্পর্কে সহজ ও প্রয়োজনীয় শিক্ষা।"}
];
function getBooks(){try{return JSON.parse(localStorage.getItem(KEY))||fallback}catch(e){return fallback}}
function saveBooks(b){localStorage.setItem(KEY,JSON.stringify(b))}
function money(n){return "৳"+Number(n).toLocaleString("bn-BD")}
const form=document.querySelector("#bookForm");
function render(){
 const books=getBooks(), list=document.querySelector("#adminList");
 document.querySelector("#bookCount").textContent=books.length.toLocaleString("bn-BD");
 const prices=books.map(b=>Number(b.price)||0);
 document.querySelector("#minPrice").textContent=money(Math.min(...prices,0));
 document.querySelector("#maxPrice").textContent=money(Math.max(...prices,0));
 list.innerHTML=books.map(b=>`<div class="admin-item"><img src="${b.image||"assets/logo.jpg"}" alt=""><div><h3>${b.name}</h3><p>${b.author||"—"} • ${money(b.price)}</p><p>${b.description||""}</p></div><div class="actions"><button class="ghost" onclick="editBook('${b.id}')">এডিট</button><button class="ghost danger" onclick="deleteBook('${b.id}')">মুছুন</button></div></div>`).join("");
}
function resetForm(){form.reset();document.querySelector("#bookId").value="";document.querySelector("#formTitle").textContent="নতুন বই যোগ করুন"}
window.editBook=function(id){
 const b=getBooks().find(x=>x.id===id);if(!b)return;
 document.querySelector("#bookId").value=b.id;document.querySelector("#name").value=b.name;document.querySelector("#price").value=b.price;document.querySelector("#author").value=b.author||"";document.querySelector("#image").value=b.image||"";document.querySelector("#description").value=b.description||"";
 document.querySelector("#formTitle").textContent="বইয়ের তথ্য পরিবর্তন করুন";scrollTo({top:0,behavior:"smooth"});
}
window.deleteBook=function(id){if(!confirm("এই বইটি মুছে ফেলবেন?"))return;saveBooks(getBooks().filter(b=>b.id!==id));render()}
form.addEventListener("submit",e=>{
 e.preventDefault(); const books=getBooks(); const id=document.querySelector("#bookId").value;
 const data={id:id||Date.now().toString(),name:document.querySelector("#name").value.trim(),price:Number(document.querySelector("#price").value),author:document.querySelector("#author").value.trim(),image:document.querySelector("#image").value.trim(),description:document.querySelector("#description").value.trim()};
 const i=books.findIndex(b=>b.id===id); if(i>=0)books[i]=data;else books.unshift(data); saveBooks(books);resetForm();render();
});
document.querySelector("#cancelBtn").addEventListener("click",resetForm);
document.querySelector("#resetBtn").addEventListener("click",()=>{if(confirm("ডেমো বইগুলো ফিরিয়ে আনবেন?")){localStorage.removeItem(KEY);render()}});
render();
